# FYPMaza

USERS:
*1. LAWYER*
    - Log In & SignUp.
    - Home
    - Add client.
    - Add case. (this add case for option dropdown for clients to choose their case that offers from firm)
    - Appointment calendar (add client for appointment consult in calendar). Should have pick time too.
    - Messages from clients (login client) to ask for available appointment dates. (have to choose approve or reject)
    - Successful case.

*2. CLIENT*
    - Log In & SignUp.
    - Home
    - Doing the appointment. :- need to fill a form like a name, gender, address, no phone, case (have dropdown option case that will get from add case lawyer), date, and time.
    - After send that, client need to wait for approval from the lawyer.
    - Client will get the message that will show in homepage if the lawyer accept or reject the appointment.